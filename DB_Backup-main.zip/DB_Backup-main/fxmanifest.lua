fx_version 'cerulean'
games { 'gta5' }
author 'saltshani1'



server_scripts {'src/server.js'}

dependencies {
    'yarn',
    'webpack'
}